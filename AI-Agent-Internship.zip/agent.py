
import json
from datetime import datetime

from langchain.tools import tool
from langchain.agents import create_agent
from langgraph.checkpoint.memory import InMemorySaver


# =========================
# TOOL 1: Calculator
# =========================

@tool
def calculator(expression: str) -> str:
    """Calculate a mathematical expression."""

    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception:
        return "Invalid mathematical expression."


# =========================
# TOOL 2: Company Policy
# =========================

@tool
def company_policy_lookup(query: str) -> str:
    """Search the company policy database and return the relevant policy."""

    with open(
        "data/company_policies.json",
        "r"
    ) as f:
        policies = json.load(f)

    query = query.lower()

    for keyword, policy in policies.items():
        if keyword in query:
            return policy

    return "No matching company policy was found."


# =========================
# TOOL 3: Employee Database
# =========================

employee_database = {
    "khushi": {
        "department": "AI/ML",
        "role": "Intern",
        "status": "Active"
    },
    "ranjan": {
        "department": "Frontend",
        "role": "Intern",
        "status": "Active"
    },
    "kousick": {
        "department": "Backend",
        "role": "Intern",
        "status": "Active"
    }
}


@tool
def database_query(name: str) -> str:
    """Look up employee information from the company database."""

    name = name.lower()

    if name in employee_database:
        employee = employee_database[name]

        return (
            f"Name: {name.title()}\n"
            f"Department: {employee['department']}\n"
            f"Role: {employee['role']}\n"
            f"Status: {employee['status']}"
        )

    return "Employee not found."


# =========================
# TOOL 4: Date and Time
# =========================

@tool
def date_time_tool() -> str:
    """Return the current date and time."""

    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# =========================
# TOOL 5: Salary Calculator
# =========================

@tool
def salary_calculator(
    monthly_salary: float,
    months: int
) -> str:
    """Calculate total salary for a given number of months."""

    total = monthly_salary * months

    return f"Total salary for {months} months is ₹{total:,.2f}."


# =========================
# ALL TOOLS
# =========================

tools = [
    calculator,
    company_policy_lookup,
    database_query,
    date_time_tool,
    salary_calculator
]


# =========================
# MEMORY
# =========================

checkpointer = InMemorySaver()


# =========================
# AGENT
# =========================

agent = create_agent(
    model=llm,
    tools=tools,
    checkpointer=checkpointer,
    system_prompt="""
    You are a helpful company assistant.

    Use the available tools whenever appropriate.

    Never invent company information.

    Give clear and concise answers.
    """
)
