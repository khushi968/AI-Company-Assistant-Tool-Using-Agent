
from agent import agent


config = {
    "configurable": {
        "thread_id": "company-assistant-1"
    }
}


print("====================================")
print("       AI COMPANY ASSISTANT")
print("====================================")
print("Type 'exit' to quit.\n")


while True:

    user_input = input("You: ")

    if user_input.lower() in ["exit", "quit"]:
        print("Agent: Goodbye!")
        break

    result = agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": user_input
                }
            ]
        },
        config=config
    )

    print(
        "Agent:",
        result["messages"][-1].content
    )
